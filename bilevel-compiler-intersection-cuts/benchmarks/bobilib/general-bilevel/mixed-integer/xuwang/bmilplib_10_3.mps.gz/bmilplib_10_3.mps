* ENCODING=ISO-8859-1
NAME          bmilplib_10_3
ROWS
 N  cost    
 L  l0      
 L  l1      
 L  l2      
 L  l3      
 L  f0      
 L  f1      
 L  f2      
 L  f3      
COLUMNS
    MARK0000  'MARKER'                 'INTORG'
    x0        cost                          -18
    x0        l0                              5
    x0        l1                              3
    x0        l2                              1
    x0        l3                              6
    x0        f0                              6
    x0        f1                              5
    x0        f2                              9
    x0        f3                              2
    x1        l0                              8
    x1        l1                              4
    x1        l3                              2
    x1        f0                              3
    x1        f1                              1
    x1        f2                             10
    x1        f3                              7
    x2        cost                           31
    x2        l0                              1
    x2        l1                              3
    x2        l2                              4
    x2        l3                              5
    x2        f0                              5
    x2        f1                              7
    x2        f2                              5
    x2        f3                              7
    x3        cost                            1
    x3        l0                              5
    x3        l1                              9
    x3        l2                              5
    x3        l3                             10
    x3        f0                              5
    x3        f1                              7
    x3        f2                              5
    x3        f3                             10
    x4        cost                           36
    x4        l0                              7
    x4        l1                             10
    x4        l2                              2
    x4        l3                              7
    x4        f0                              2
    x4        f1                              1
    x4        f2                              1
    x5        cost                           45
    x5        l0                              3
    x5        l1                              7
    x5        l2                              7
    x5        f0                              4
    x5        f1                              4
    x5        f2                              4
    x5        f3                              8
    x6        cost                          -35
    x6        l0                              2
    x6        l1                              2
    x6        l2                              7
    x6        l3                              9
    x6        f0                              6
    x6        f1                              8
    x6        f2                             10
    x6        f3                             10
    x7        cost                           -6
    x7        l0                              3
    x7        l1                              8
    x7        l2                              7
    x7        f0                              2
    x7        f1                              1
    x7        f2                              7
    x7        f3                              1
    x8        cost                          -43
    x8        l0                              6
    x8        l1                              4
    x8        l2                             10
    x8        f0                              5
    x8        f1                              5
    x8        f2                              9
    x8        f3                              5
    x9        cost                          -20
    x9        l0                              5
    x9        l1                              4
    x9        l2                              5
    x9        l3                              8
    x9        f0                              4
    x9        f1                              7
    x9        f2                              8
    x9        f3                              5
    MARK0001  'MARKER'                 'INTEND'
    y0        cost                           -8
    y0        l0                              3
    y0        l1                              8
    y0        l2                              5
    y0        f0                              3
    y0        f1                              1
    y0        f2                              6
    y0        f3                              2
    y1        cost                          -32
    y1        l0                              1
    y1        l1                              7
    y1        l2                              5
    y1        l3                              1
    y1        f1                              8
    y1        f2                              2
    y1        f3                              4
    MARK0002  'MARKER'                 'INTORG'
    y2        cost                          -38
    y2        l0                              3
    y2        l1                              6
    y2        l2                              2
    y2        l3                              8
    y2        f0                              7
    y2        f1                              3
    y2        f2                              8
    y2        f3                              4
    y3        cost                          -49
    y3        l0                              2
    y3        l1                             10
    y3        l2                              2
    y3        l3                              8
    y3        f0                              7
    y3        f1                              7
    y3        f2                              4
    y4        cost                           50
    y4        l0                              2
    y4        l1                              3
    y4        l2                              1
    y4        l3                              6
    y4        f0                              3
    y4        f1                              4
    y4        f2                              2
    y4        f3                              2
    MARK0003  'MARKER'                 'INTEND'
    y5        cost                          -37
    y5        l0                              7
    y5        l1                              6
    y5        l2                              4
    y5        l3                              7
    y5        f0                              9
    y5        f1                              4
    y5        f2                              9
    y5        f3                              4
    MARK0004  'MARKER'                 'INTORG'
    y6        cost                          -11
    y6        l0                              7
    y6        l1                              7
    y6        l2                              6
    y6        l3                             10
    y6        f0                              8
    y6        f1                              4
    y6        f2                              8
    y6        f3                              8
    MARK0005  'MARKER'                 'INTEND'
    y7        cost                          -49
    y7        l0                              2
    y7        l1                              7
    y7        l2                              2
    y7        l3                              1
    y7        f0                              4
    y7        f1                              2
    y7        f2                              8
    y7        f3                             10
    y8        cost                           -3
    y8        l0                              6
    y8        l1                              4
    y8        l2                              5
    y8        l3                              7
    y8        f0                              3
    y8        f1                              7
    y8        f2                              4
    y8        f3                              9
    y9        cost                            2
    y9        l0                              8
    y9        l1                              3
    y9        l2                              7
    y9        l3                              4
    y9        f0                              8
    y9        f1                              1
    y9        f2                              9
    y9        f3                             10
RHS
    rhs       l0                            115
    rhs       l1                            114
    rhs       l2                             55
    rhs       l3                             91
    rhs       f0                             61
    rhs       f1                             99
    rhs       f2                             69
    rhs       f3                             25
BOUNDS
 UP bnd       x0                             10
 UP bnd       x1                             10
 UP bnd       x2                             10
 UP bnd       x3                             10
 UP bnd       x4                             10
 UP bnd       x5                             10
 UP bnd       x6                             10
 UP bnd       x7                             10
 UP bnd       x8                             10
 UP bnd       x9                             10
 LI bnd       y2        0
 LI bnd       y3        0
 LI bnd       y4        0
 LI bnd       y6        0
ENDATA
